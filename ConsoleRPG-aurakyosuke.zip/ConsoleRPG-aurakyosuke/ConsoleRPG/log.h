#pragma once
#include <iostream>
using namespace std;

void PrintConsoleMessage(string message, int value)
{
	cout << " " << message << value << endl;
}