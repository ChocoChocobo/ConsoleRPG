#pragma once
#ifndef CHARACTER_CREATOR
#define CHARACTER_CREATOR
#include "character.h"

Characteristics DistributeCharacteristics();

//Appearance DefineAppearance();

#endif // !CHARACTER_CREATOR